function [ correspondence_error ] = calcCorrespondenceError( image, patch_image, x, y )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[height, width, c] = size(image);
[patch_height, patch_width, c] = size(patch_image);

region_width = min(patch_width, width + 1 - x);
region_height = min(patch_height, height + 1 - y);

image_region = image(y:y + region_height - 1, x:x + region_width - 1, :);
patch_image_region = patch_image(1:region_height, 1:region_width, :);

image_region = imgaussfilt(image_region);
patch_image_region = imgaussfilt(patch_image_region);

image_region_intensity = sum(double(image_region), 3) / 3 / 255;
patch_image_region_intensity = sum(double(patch_image_region), 3) / 3 / 255;
image_region_intensity = image_region_intensity(:);
patch_image_region_intensity = patch_image_region_intensity(:);

correspondence_error = sum((image_region_intensity - patch_image_region_intensity).^2) / numel(image_region_intensity);


end

