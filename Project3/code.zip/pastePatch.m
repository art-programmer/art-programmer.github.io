function [ synthesized_image ] = pastePatch( image, patch_image, x, y )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

synthesized_image = image;

[height, width, c] = size(image);
[patch_height, patch_width, c] = size(patch_image);

region_width = min(patch_width, width + 1 - x);
region_height = min(patch_height, height + 1 - y);
synthesized_image(y:y + region_height - 1, x:x + region_width - 1, :) = patch_image(1:region_height, 1:region_width, :);

end