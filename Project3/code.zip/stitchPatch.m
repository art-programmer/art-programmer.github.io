function [ synthesized_image ] = stitchPatch( image, patch_image, start_x, start_y )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

addpath('/Users/chenliu/Documents/MATLAB/GCMex');

synthesized_image = image;

[height, width, c] = size(image);
[patch_height, patch_width, c] = size(patch_image);

region_width = min(patch_width, width + 1 - start_x);
region_height = min(patch_height, height + 1 - start_y);

image_region = image(start_y:start_y + region_height - 1, start_x:start_x + region_width - 1, :);
patch_image_region = patch_image(1:region_height, 1:region_width, :);


segclass = ones(region_width * region_height, 1);
pairwise = sparse(region_width * region_height, region_width * region_height);
unary = zeros(2, region_width * region_height);
labelcost = zeros(2, 2);
labelcost(1, 2) = 1;
labelcost(2, 1) = 1;

for x = 1:region_width - 1
    for y = 1:region_height
        image_color_1 = double(image_region(y, x, :));
        patch_color_1 = double(patch_image_region(y, x, :));
        image_color_2 = double(image_region(y, x + 1, :));
        patch_color_2 = double(patch_image_region(y, x + 1, :));
        color_diff = norm(image_color_1(:) - patch_color_1(:)) + norm(image_color_2(:) - patch_color_2(:));
        pairwise(y + (x - 1) * region_height, y + (x + 1 - 1) * region_height) = color_diff;
    end
end
for x = 1:region_width
    for y = 1:region_height - 1
        image_color_1 = double(image_region(y, x, :));
        patch_color_1 = double(patch_image_region(y, x, :));
        image_color_2 = double(image_region(y + 1, x, :));
        patch_color_2 = double(patch_image_region(y + 1, x, :));
        color_diff = norm(image_color_1(:) - patch_color_1(:)) + norm(image_color_2(:) - patch_color_2(:));
        pairwise(y + (x - 1) * region_height, y + 1 + (x - 1) * region_height) = color_diff;
    end
end
pairwise = (pairwise + pairwise');

mask = image_region(:, :, 1) == 0;
unary(1, find(mask)) = 1000000;
if start_x > 2
    for y = 1:region_height
        image_color_1 = double(image(start_y - 1 + y, start_x - 1, :));
        patch_color_1 = double(patch_image(y, 1, :));
        image_color_2 = double(image(start_y - 1 + y, start_x - 2, :));
        patch_color_2 = double(patch_image(y, 1, :));
        color_diff = norm(image_color_1(:) - patch_color_1(:)) + norm(image_color_2(:) - patch_color_2(:));
        unary(2, y) = unary(2, y) + color_diff;
    end
end
if start_y > 2
    for x = 1:region_width
        image_color_1 = double(image(start_y - 1, start_x - 1 + x, :));
        patch_color_1 = double(patch_image(1, x, :));
        image_color_2 = double(image(start_y - 2, start_x - 1 + x, :));
        patch_color_2 = double(patch_image(1, x, :));
        color_diff = norm(image_color_1(:) - patch_color_1(:)) + norm(image_color_2(:) - patch_color_2(:));
        unary(2, 1 + (x - 1) * region_height) = unary(2, 1 + (x - 1) * region_height) + color_diff;
    end
end

[labels E Eafter] = GCMex(segclass, single(unary), pairwise, single(labelcost), 0);


% if (numel(find(mask)) == region_width * region_height)
%     cut_result = zeros(region_width * region_height, 1);
% else
%     [cut_result, cut_value] = mincut(weights, find(mask));
% end

labels = reshape(labels, region_height, region_width);
patch_mask = logical(cat(3, labels, labels, labels));

copy_region = image(start_y:start_y + region_height - 1, start_x:start_x + region_width - 1, :);
copy_region(patch_mask) = patch_image_region(patch_mask);
synthesized_image(start_y:start_y + region_height - 1, start_x:start_x + region_width - 1, :) = copy_region;

end