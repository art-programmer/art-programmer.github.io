function [ synthesized_image ] = textureSynthesis( width, height, texture_image_filename, patch_size, method, overlap_width, num_patch_samples )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

texture_image = imread(texture_image_filename);
synthesized_image = uint8(zeros(height, width, 3));
if (method == 0)
    for x = 1:patch_size:width
        for y = 1:patch_size:height
            synthesized_image = pastePatch(synthesized_image, randomSamplePatch(texture_image, patch_size), x, y);
        end
    end
end
if (method == 1)
    for x = 1:patch_size - overlap_width:width
        for y = 1:patch_size - overlap_width:height
            min_SSD = inf;
            for sample_index = 1:num_patch_samples;
                patch_image = randomSamplePatch(texture_image, patch_size);
                SSD = calcSSD(synthesized_image, patch_image, x, y);
                if SSD < min_SSD
                    min_SSD_patch_image = patch_image;
                    min_SSD = SSD;
                end
            end
            synthesized_image = pastePatch(synthesized_image, min_SSD_patch_image, x, y);
        end
    end
end
if (method == 2)
    for x = 1:patch_size - overlap_width:width
        for y = 1:patch_size - overlap_width:height
            min_SSD = inf;
            for sample_index = 1:num_patch_samples;
                patch_image = randomSamplePatch(texture_image, patch_size);
                SSD = calcSSD(synthesized_image, patch_image, x, y);
                if SSD < min_SSD
                    min_SSD_patch_image = patch_image;
                    min_SSD = SSD;
                end
            end
            synthesized_image = stitchPatch(synthesized_image, min_SSD_patch_image, x, y);
        end
    end
end

end

