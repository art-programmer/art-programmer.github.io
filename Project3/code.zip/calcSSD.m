function [ SSD ] = calcSSD( image, patch_image, x, y )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

[height, width, c] = size(image);
[patch_height, patch_width, c] = size(patch_image);

region_width = min(patch_width, width + 1 - x);
region_height = min(patch_height, height + 1 - y);

image_region = image(y:y + region_height - 1, x:x + region_width - 1, :);
patch_image_region = patch_image(1:region_height, 1:region_width, :);
mask = (image_region(:, :, 1) ~= 0) | (image_region(:, :, 2) ~= 0) | (image_region(:, :, 3) ~= 0);
mask = cat(3, mask, mask, mask);
image_values = double(image_region(mask)) / 255;
patch_image_values = double(patch_image_region(mask)) / 255;

if numel(image_values) == 0
    SSD = 0;
else
    SSD = sum((image_values - patch_image_values).^2) / numel(image_values);
end

end

