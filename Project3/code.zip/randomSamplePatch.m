function [ patch_image ] = randomSamplePatch( texture_image, patch_size )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[height, width, c] = size(texture_image);
min_x = 1;
min_y = 1;
max_x = width + 1 - patch_size;
max_y = height + 1 - patch_size;
x = uint16(min_x + rand() * (max_x - min_x));
y = uint16(min_y + rand() * (max_y - min_y));

patch_image = texture_image(y:y + patch_size - 1, x:x + patch_size - 1, :);

end

