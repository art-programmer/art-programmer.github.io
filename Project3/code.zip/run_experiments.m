% image_name = 'mess';
% synthesized_image_1 = textureSynthesis(400, 400, sprintf('%s.jpg', image_name), 100, 1, 50, 20);
% imwrite(synthesized_image_1, sprintf('%s_result_1.png', image_name));
% synthesized_image_2 = textureSynthesis(400, 400, sprintf('%s.jpg', image_name), 100, 2, 50, 20);
% imwrite(synthesized_image_2, sprintf('%s_result_2.png', image_name));

synthesized_image = textureTransfer('a1.jpg', 'oranges.jpg', 50, 30, 20);
imwrite(synthesized_image, 'a1_result.png');