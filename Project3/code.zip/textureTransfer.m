function [ synthesized_image ] = textureTransfer( target_image_filename, texture_image_filename, patch_size, overlap_width, num_patch_samples )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

N = 1;

target_image = imread(target_image_filename);
[height, width, c] = size(target_image);

texture_image = imread(texture_image_filename);

previous_synthesized_image = uint8(zeros(height, width, 3));
for iter = 1:N
    if (N == 1)
        alpha = 0.1;
    else
        alpha = 0.8 * (i - 1) / (N - 1) + 0.1;
    end
    synthesized_image = uint8(zeros(height, width, 3));
    
    for y = 1:patch_size - overlap_width:height
        for x = 1:patch_size - overlap_width:width
            min_error = inf;
            for sample_index = 1:num_patch_samples;
                patch_image = randomSamplePatch(texture_image, patch_size);
                SSD_overlap = calcSSD(synthesized_image, patch_image, x, y);
                SSD_previous = calcSSD(previous_synthesized_image, patch_image, x, y);
                correspondence_error = calcCorrespondenceError(target_image, patch_image, x, y);
                error = alpha * (SSD_overlap + SSD_previous) + (1 - alpha) * correspondence_error;
                if error < min_error
                    min_error_patch_image = patch_image;
                    min_error = error;
                end
            end
            synthesized_image = stitchPatch(synthesized_image, min_error_patch_image, x, y);
            imshow(synthesized_image)
        end
    end
    previous_synthesized_image = synthesized_image;
    patch_size = ceil(patch_size * 2 / 3);
    overlap_width = ceil(overlap_width * 2 / 3);
end

end